/*
 * Programación Interactiva
 * Equipo de trabajo:
 * -Andres Pineda Cortez   1843660-3743
 * -Mateo Obando Gutierrez 1844983-3743
 * Proyecto. Entrega # 1 -Juego Ocho Loco
 */

package archivos;

import javax.swing.ImageIcon;
import javax.swing.JButton;

// TODO: Auto-generated Javadoc
/**
 * The Class Carta.
 */
@SuppressWarnings("serial")
public class Carta extends JButton{
	/** The cara. 
	 * es la imagen de la carta, basada en su tipo y numero
	 * */
	private ImageIcon cara;
	
	/** The identificador.
	 * es el numero de la carta
	 *  */
	private int identificador;
	
	/** The tipo. 
	 * es el tipo de carta, puede ser de corazones, diamantes, treboles o picas
	 * */
	private String tipo;

	/**
	 * Gets the cara.
	 *
	 * @return the cara
	 */
	public ImageIcon getCara() {
		return cara;
	}

	/**
	 * Sets the cara.
	 * 
	 * @param tamano the new cara
	 * cambia la cara de la carta segun su tipo y numero
	 */
	public void setCara(String tamano) {
		cara = new ImageIcon("src/Imagenes/Cartas "+tamano+"/"+identificador+tipo+".png");
	}

	/**
	 * Gets the identificador.
	 *
	 * @return the identificador
	 */
	public int getIdentificador() {
		return identificador;
	}

	/**
	 * Sets the identificador.
	 * ingresa un entero y este sera el numero de la carta
	 * @param identificador the new identificador
	 */
	public void setIdentificador(int identificador) {
		this.identificador = identificador;
	}

	/**
	 * Gets the tipo.
	 *
	 * @return the tipo
	 */
	public String getTipo() {
		return tipo;
	}

	/**
	 * Sets the tipo.
	 * ingresa un string y este sera el tipo de carta
	 * @param tipo the new tipo
	 */
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
}
