/*
 * 
 */
package archivos;

import javax.swing.ImageIcon;
import javax.swing.JButton;

/**
 * The Class Carta.
 */
@SuppressWarnings("serial")
public class Carta extends JButton{
	/** The cara. */
	private ImageIcon cara;
	
	/** The identificador. */
	private int identificador;
	
	/** The tipo. */
	private String tipo;

	/**
	 * Gets the cara.
	 *
	 * @return the cara
	 */
	public ImageIcon getCara() {
		return cara;
	}

	/**
	 * Sets the cara.
	 *
	 * @param tamano the new cara
	 */
	public void setCara(String tamano) {
		cara = new ImageIcon("src/Imagenes/Cartas "+tamano+"/"+identificador+tipo+".png");
	}

	/**
	 * Gets the identificador.
	 *
	 * @return the identificador
	 */
	public int getIdentificador() {
		return identificador;
	}

	/**
	 * Sets the identificador.
	 *
	 * @param identificador the new identificador
	 */
	public void setIdentificador(int identificador) {
		this.identificador = identificador;
	}

	/**
	 * Gets the tipo.
	 *
	 * @return the tipo
	 */
	public String getTipo() {
		return tipo;
	}

	/**
	 * Sets the tipo.
	 *
	 * @param tipo the new tipo
	 */
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
}
