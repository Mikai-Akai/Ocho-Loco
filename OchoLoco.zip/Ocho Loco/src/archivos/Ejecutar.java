/*
 * Programaci�n Interactiva
 * Equipo de trabajo:
 * -Andres Pineda Cortez   1843660-3743
 * -Mateo Obando Gutierrez 1844983-3743
 * Proyecto. Entrega # 1 -Juego Ocho Loco
 */
package archivos;

import java.awt.EventQueue;

import javax.swing.UIManager;

// TODO: Auto-generated Javadoc
/**
 * The Class Ejecutar.
 */
public class Ejecutar {

	/**
	 * The main method.
	 *
	 * @param args the arguments
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			String className = UIManager.getCrossPlatformLookAndFeelClassName();
			UIManager.setLookAndFeel(className);
		}
		catch(Exception e) {
			
		}
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				@SuppressWarnings("unused")
				GUIOchoLoco juego = new GUIOchoLoco();
				}
			});
	}

}
