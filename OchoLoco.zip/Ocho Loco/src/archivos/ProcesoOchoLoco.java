/*
 * 
 */
package archivos;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

// TODO: Auto-generated Javadoc
/**
 * The Class ProcesoOchoLoco.
 */
public class ProcesoOchoLoco {
	
	/** The baraja. */
	private ArrayList<Carta> baraja = new ArrayList<Carta>(0);
	
	/** The en mano jugador 1. */
	private ArrayList<Carta> enManoJugador1 = new ArrayList<Carta>(0);
	
	/** The en mano jugador 2. */
	private ArrayList<Carta> enManoJugador2 = new ArrayList<Carta>(0);
	
	/** The en juego. */
	private ArrayList<Carta> enJuego = new ArrayList<Carta>(0);
	
	/** The aleatorio. */
	private Random aleatorio = new Random();
	
	/** The turno. */
	private boolean turno = true;
	/**
	 * Crear baraja.
	 *
	 * @param e the e
	 */
	public void crearBaraja(ArrayList<Carta> e) {
		for(int i = 1; i<53;i++) {
			//se crea la plantilla a usar para generar carta y se le asigna un tipo y numero
			Carta carta = new Carta();
			if(i <= 13 && i > -1) {
				carta.setTipo("Corazones");
				carta.setIdentificador(i);	
			}else if(i <= 26 && i > 13) {
				carta.setTipo("Diamantes");
				carta.setIdentificador(i-13);
			}else if(i <= 39 && i > 26) {
				carta.setTipo("Treboles");
				carta.setIdentificador(i-26);
			}else if(i <= 52 && i > 39) {
				carta.setTipo("Picas");
				carta.setIdentificador(i-39);
			}else {
				//si por algun motivo no se puede asignar un numero y tipo a la carta, se limpia la baraja y se reinicia la funcion.
				e.clear();
				crearBaraja(e);
			}
			//en el momento que la carta esta lista se añade a la baraja
			e.add(carta);
		}
	}
	
	/**
	 * Revolver baraja.
	 *
	 * @param r the r
	 */
	public void revolverBaraja(ArrayList<Carta> r) {
		//mediante la funcion shuffle mezclamos la posicion de las cartas con un indice aleatorio, cada vez que se revuelven quedan en distinta posicion
		Collections.shuffle(r, aleatorio);
	}
	
	/**
	 * Sacar primer carta.
	 */
	public void sacarPrimerCarta() {
		enJuego.add(baraja.remove(0));
	}
	
	/**
	 * Iniciar juego.
	 */
	public void iniciarJuego() {
		//funcion que da inicio a la fase 1 del juego, la creacion de la baraja, el posicionamiento de la primera carta y la entrega de cartas a los jugadores
		crearBaraja(baraja);
		revolverBaraja(baraja);
		sacarPrimerCarta();
		repartirCartas();
	}
	
	/**
	 * Repartir cartas.
	 * se le dan 8 cartas a cada jugador
	 */
	public void repartirCartas() {
		for(int a = 0; a <9;a++) {
			Carta auxiliar = baraja.get(0);
			baraja.remove(0);
			enManoJugador1.add(auxiliar);
			}
		for(int b = 0; b <9;b++) {
			Carta auxiliar = baraja.get(0);
			baraja.remove(0);
			enManoJugador2.add(auxiliar);
		}
	}
	/**
	 * Reunir mazos.
	 */
	public void limpiarMazos() {
		//resta funcion elimina las cartas en todos los mazos para un nuevo juego
		baraja.clear();
		enJuego.clear();
		enManoJugador1.clear();
		enManoJugador2.clear();
	}
	
	/**
	 * Jugador automatico.
	 */
	public void jugadorAutomatico() {
		int contador = 0;
		//este será el jugador "computador", primero usa la funcion evaluar cartas
		for(int i = 0; i < enManoJugador2.size();i++) {
			if(evaluarCartas(enManoJugador2.get(i))) {
				//si puede dejar una carta lo hace y termina su ejecucion
				dejarCarta(enManoJugador2,i);
				break;
			}else {
				// si no puede dejar una carta, revisa la siguiente, si el contador llega a ser del tamaño del arreglo, significa que no encotró carta similar y procede a comer
				contador++;
				if(contador == enManoJugador2.size()) {
					tomarCarta(enManoJugador2);
				}
			}
		}
	}
	
	/**
	 * Evaluar cartas.
	 *
	 * @param enMano the en mano
	 * @return true
	 */
	public boolean evaluarCartas(Carta enMano) {
		//la carta a evaluar en mano del jugador depende de la posicion que se asigne a evaluar
		Carta base = enJuego.get(enJuego.size()-1);
		//la carta base tiene la posicion final de la baraja de usadas en juego y la compara 
		if(enMano.getIdentificador() == base.getIdentificador() || enMano.getTipo() == base.getTipo()) {
			return true;
		}else {
			return false;
			// si no se cumple ninguna de las anteriores, es que la carta no coincide
			}
		}
	
	/**
	 * Tomar carta.
	 *se recoge una carta del mazo para añadirlo a la mano del jugador
	 * @param Jugador the jugador
	 */
	public void tomarCarta(ArrayList<Carta> Jugador) {
		Carta auxiliar = baraja.get(baraja.size()-1);
		baraja.remove(baraja.size()-1);
		Jugador.add(auxiliar);
	}
	
	/**
	 * Dejar carta.
	 * se deja una carta del mazo del jugador en la pila de usadas
	 *
	 * @param Jugador the jugador
	 * @param i the i
	 */
	public void dejarCarta(ArrayList<Carta> Jugador, int i) {
		if(evaluarCartas(Jugador.get(i))) {
			Carta auxiliar = Jugador.get(i);
			Jugador.remove(i);
			enJuego.add(auxiliar);};
	}
	
	/**
	 * Gets the turno.
	 *solicita el turno actual en juego, true es el jugador y false es el computador
	 * @return the turno
	 */
	public boolean getTurno() {
		return turno;
	}
	
	/**
	 * Sets the turno.
	 * cambia el turno por su opuesto
	 */
	public void setTurno() {
		turno = !turno;
	}
	/**
	 * Gets the baraja J 1.
	 *
	 * @return the baraja J 1
	 */
	public ArrayList<Carta> getBarajaJ1() {
		return enManoJugador1;
	}
	
	/**
	 * Gets the baraja J 2.
	 *
	 * @return the baraja J 2
	 */
	public ArrayList<Carta> getBarajaJ2() {
		return enManoJugador2;
	}
	
	/**
	 * Gets the usadas.
	 *
	 * @return the usadas
	 */
	public ArrayList<Carta >getusadas() {
		return enJuego;
	}
}