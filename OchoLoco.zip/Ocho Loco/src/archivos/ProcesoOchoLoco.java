/*
 * 
 */
package archivos;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

// TODO: Auto-generated Javadoc
/**
 * The Class ProcesoOchoLoco.
 */
public class ProcesoOchoLoco {
	
	/** The baraja. 
	 * el mazo inicial del cual se remueven las cartas
	 * */
	private ArrayList<Carta> baraja = new ArrayList<Carta>(0);
	
	/** The en mano jugador 1. 
	 * el mazo del jugador 1. el jugador 1 es el usuario
	 * */
	private ArrayList<Carta> enManoJugador1 = new ArrayList<Carta>(0);
	
	/** The en mano jugador 2. 
	 * el mazo del jugador 2. el jugador 2 es el computador
	 * */
	private ArrayList<Carta> enManoJugador2 = new ArrayList<Carta>(0);
	
	/** The en juego. 
	 * las cartas que se han usado y la ultima es la que esta arriba del  mazo
	 * */
	private ArrayList<Carta> enJuego = new ArrayList<Carta>(0);
	
	/** The aleatorio. 
	 * numero aleatorio usado como semilla para revolver las cartas
	 */
	private Random aleatorio = new Random();
	
	/** The turno. */
	private boolean turno = true;
	/**
	 * Crear baraja.
	 * se crea la plantilla a usar para generar carta y se le asigna un tipo y numero
	 * si por algun motivo no se puede asignar un numero y tipo a la carta, se limpia la baraja y se reinicia la funcion.
	 * en el momento que la carta esta lista se añade a la baraja
	 * @param e the e
	 */
	public void crearBaraja(ArrayList<Carta> e) {
		for(int i = 1; i<53;i++) {
			Carta carta = new Carta();
			if(i <= 13 && i > -1) {
				carta.setTipo("Corazones");
				carta.setIdentificador(i);	
			}else if(i <= 26 && i > 13) {
				carta.setTipo("Diamantes");
				carta.setIdentificador(i-13);
			}else if(i <= 39 && i > 26) {
				carta.setTipo("Treboles");
				carta.setIdentificador(i-26);
			}else if(i <= 52 && i > 39) {
				carta.setTipo("Picas");
				carta.setIdentificador(i-39);
			}else {
				e.clear();
				crearBaraja(e);
			}e.add(carta);
		}
	}
	
	/**
	 * Revolver baraja.
	 * mediante la funcion shuffle mezclamos la posicion de las cartas con un indice aleatorio, cada vez que se revuelven quedan en distinta posicion
	 * @param r the r
	 * el parametro r es un array list que va a ser reordenado
	 */
	public void revolverBaraja(ArrayList<Carta> r) {
		Collections.shuffle(r, aleatorio);
	}
	
	/**
	 * Sacar primer carta.
	 * funcion que remueve la primera carta del mazo para iniciar el juego
	 */
	public void sacarPrimerCarta() {
		Carta auxiliar = baraja.get(baraja.size()-1);
		baraja.remove(baraja.size()-1);
		enJuego.add(auxiliar);
	}
	
	/**
	 * Iniciar juego.
	 * esta funcion crea la baraja, la mezcla y reparte las cartas entre los 2 jugadores
	 */
	public void iniciarJuego() {
		crearBaraja(baraja);
		revolverBaraja(baraja);
		sacarPrimerCarta();
		repartirCartas();
	}
	
	/**
	 * Repartir cartas.
	 * se le dan 8 cartas a cada jugador
	 */
	public void repartirCartas() {
		for(int a = 0; a <9;a++) {
			Carta auxiliar = baraja.get(0);
			baraja.remove(0);
			enManoJugador1.add(auxiliar);
		}
		for(int b = 0; b <9;b++) {
			Carta auxiliar = baraja.get(0);
			baraja.remove(0);
			enManoJugador2.add(auxiliar);
		}
	}
	/**
	 * Reunir mazos.
	 * resta funcion elimina las cartas en todos los mazos para un nuevo juego
	 */
	public void limpiarMazos() {
		baraja.clear();
		enJuego.clear();
		enManoJugador1.clear();
		enManoJugador2.clear();
	}
	
	/**
	 * Jugador automatico.
	 * este será el jugador "computador", primero usa la funcion evaluar cartas
	 * si puede dejar una carta lo hace y termina su ejecucion
	 * si no puede dejar una carta, revisa la siguiente, si el contador llega a ser del tamaño del arreglo, significa que no encotró carta similar y procede a comer
	 */
	public void jugadorAutomatico() {
		int contador = 0;
		for(int i = 0; i < enManoJugador2.size();i++) {
			if(evaluarCartas(enManoJugador2.get(i))) {
				dejarCarta(enManoJugador2,i);
				break;
			}else {
				contador++;
				if(contador == enManoJugador2.size()) {
					tomarCarta(enManoJugador2);
				}
			}
		}
	}
	
	/**
	 * Evaluar cartas.
	 *la carta a evaluar en mano del jugador depende de la posicion que se asigne a evaluar
	 *la carta base tiene la posicion final de la baraja de usadas en juego y la compara
	 *si no se cumple ninguna de las condiciones, es que la carta no coincide
	 * @param enMano the en mano
	 * @return true
	 */
	public boolean evaluarCartas(Carta enMano) {
		Carta base = enJuego.get(enJuego.size()-1);
		if(enMano.getIdentificador() == base.getIdentificador() || enMano.getTipo() == base.getTipo()) {
			return true;
		}else {
			return false;
		}
	}
	
	/**
	 * Tomar carta.
	 *se recoge una carta del mazo para añadirlo a la mano del jugador
	 * @param Jugador the jugador
	 */
	public void tomarCarta(ArrayList<Carta> Jugador) {
		Carta auxiliar = baraja.get(baraja.size()-1);
		baraja.remove(baraja.size()-1);
		Jugador.add(auxiliar);
	}
	
	/**
	 * Dejar carta.
	 * se deja una carta del mazo del jugador en la pila de usadas
	 *
	 * @param Jugador the jugador
	 * @param i the i
	 */
	public void dejarCarta(ArrayList<Carta> Jugador, int i) {
		if(evaluarCartas(Jugador.get(i))) {
			Carta auxiliar = Jugador.get(i);
			Jugador.remove(i);
			enJuego.add(auxiliar);
		}
	}
	
	/**
	 * Gets the turno.
	 *solicita el turno actual en juego, true es el jugador y false es el computador
	 * @return the turno
	 */
	public boolean getTurno() {
		return turno;
	}
	
	/**
	 * Sets the turno.
	 * cambia el turno por su opuesto
	 */
	public void setTurno() {
		turno = !turno;
	}
	/**
	 * Gets the baraja J 1.
	 *
	 * @return the baraja J 1
	 */
	public ArrayList<Carta> getBarajaJ1() {
		return enManoJugador1;
	}
	
	/**
	 * Gets the baraja J 2.
	 *
	 * @return the baraja J 2
	 */
	public ArrayList<Carta> getBarajaJ2() {
		return enManoJugador2;
	}
	
	/**
	 * Gets the usadas.
	 *
	 * @return the usadas
	 */
	public ArrayList<Carta >getusadas() {
		return enJuego;
	}
}