/*
 * 
 */
package archivos;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
/**
 * The Class GUIOchoLoco.
 */
@SuppressWarnings("serial")
public class GUIOchoLoco extends JFrame {
	
	/** The Tarjeta. */
	private Carta Tarjeta;
	
	/** The usadasboton. */
	private JButton comer,usadasboton;
	/** The imagen. */
	private ImageIcon imagen;
	
	/** The gano J 2. */
	private boolean ganoJ1 = false,ganoJ2 = false;
	
	/** The juego. */
	private ProcesoOchoLoco juego;
	
	/** The usadas. */
	private JPanel mazoJ1,mazoJ2,baraja,usadas;
	
	/** The escucha. */
	private Escucha escucha = new Escucha();
	
	/**
	 * Instantiates a new GUI ocho loco.
	 */
	public GUIOchoLoco(){
		juego = new ProcesoOchoLoco();
		GUIJugar();
		this.setTitle("Ocho Loco");
		this.pack();
		this.setResizable(true);
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
	}
	
	/**
	 * GUI jugar.
	 */
	private void GUIJugar() {
		Container contenedor = this.getContentPane();
		contenedor.setLayout(new BorderLayout());
		juego.iniciarJuego();
		
		
		mazoJ1 = new JPanel();
		mazoJ1.setBackground(Color.DARK_GRAY);
		for(int i = 0; i< juego.getBarajaJ1().size()-1;i++) {
			Tarjeta = juego.getBarajaJ1().get(i);
			Tarjeta.setVisible(true);
			juego.getBarajaJ1().get(i).setCara("Grandes");
			Tarjeta.setIcon(Tarjeta.getCara());
			Tarjeta.addActionListener(escucha);
			mazoJ1.add(Tarjeta);
		}
		contenedor.add(mazoJ1,BorderLayout.NORTH);
		
		mazoJ2 = new JPanel();
		mazoJ2.setBackground(Color.BLUE);
		for(int i = 0; i< juego.getBarajaJ2().size()-1;i++) {
			Tarjeta = juego.getBarajaJ2().get(i);
			Tarjeta.setVisible(true);
			juego.getBarajaJ2().get(i).setCara("Medianas");
			imagen = new ImageIcon("src/Imagenes/Cartas Medianas/Caratula.png");
			Tarjeta.setIcon(imagen);
			mazoJ2.add(Tarjeta);
		}
		contenedor.add(mazoJ2,BorderLayout.SOUTH);
		
		baraja = new JPanel();
		baraja.setBackground(Color.GRAY);
		comer = new Carta();
		imagen = new ImageIcon("src/Imagenes/Cartas Medianas/Caratula.png");
		comer.setIcon(imagen);
		baraja.add(comer);
		contenedor.add(baraja,BorderLayout.WEST);
		
		usadas = new JPanel();
		usadas.setBackground(Color.GRAY);
		usadasboton = juego.getusadas().get(juego.getusadas().size()-1);
		imagen = new ImageIcon("src/Imagenes/Cartas Medianas/"+juego.getusadas().get(juego.getusadas().size()-1).getIdentificador()+juego.getusadas().get(juego.getusadas().size()-1).getTipo()+".png");
		usadasboton.setIcon(imagen);
		usadas.add(usadasboton);
		contenedor.add(usadas,BorderLayout.EAST);
		continuarjuego();
	}
	
	/**
	 * Continuarjuego.
	 */
	public void continuarjuego() {
		if(ganoJ2 = false) {
			juego.setTurno();
			if(juego.getTurno() == false) {
				juego.jugadorAutomatico();
				}
			}
		if(ganoJ1) {
			JOptionPane.showConfirmDialog(null, "gana el jugador 1");
			System.runFinalization();
			System.exit(1);
			}else if(ganoJ2) {
				JOptionPane.showConfirmDialog(null, "gana el jugador 2");
				System.runFinalization();
				System.exit(1);
				}
		}

	/**
	 * The Class Escucha.
	 */
	private class Escucha implements ActionListener{

		/**
		 * Action performed.
		 *
		 * @param arg0 the arg 0
		 */
		@Override
		public void actionPerformed(ActionEvent arg0) {
			if(null == null){
			}
			///prueba del escucha--------------------------------------------------
			System.out.println("baraja1");
			for(int i = 0; i< juego.getBarajaJ1().size();i++) {
				System.out.print(juego.getBarajaJ1().get(i).getIdentificador());
				System.out.println(juego.getBarajaJ1().get(i).getTipo());
			}
			System.out.println("baraja2");
			for(int i = 0; i< juego.getBarajaJ2().size();i++) {
				System.out.print(juego.getBarajaJ2().get(i).getIdentificador());
				System.out.println(juego.getBarajaJ2().get(i).getTipo());
			}
			System.out.println("usadas");
			for(int i = 0; i< juego.getusadas().size();i++) {
				System.out.print(juego.getusadas().get(i).getIdentificador());
				System.out.println(juego.getusadas().get(i).getTipo());
			}
			
			if(juego.getBarajaJ1().size()==0) {
				ganoJ1=true;
			}else if(juego.getBarajaJ2().size()==0) {
				ganoJ2=true;
			}else {
				continuarjuego();
			}
			
			//fin de prueba del escucha---------------------------------------------
		}

	}
}
