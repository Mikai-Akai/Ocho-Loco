/*
 * Programación Interactiva
 * Equipo de trabajo:
 * -Andres Pineda Cortez   1843660-3743
 * -Mateo Obando Gutierrez 1844983-3743
 * Proyecto. Entrega # 1 -Juego Ocho Loco
 */

package archivos;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 * The Class GUIOchoLoco.
 */
public class GUIOchoLoco extends JFrame {
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1;

	/** The Tarjeta. 
	 * cada carta sera agregada mediante esta variable a su posicion en el juego
	 * */
	private Carta Tarjeta;
	
	/** The usadasboton.
	 * es un boton no clickable en el cual se ve la ultima carta jugada
	 * el boton para 
	 * */
	private Carta usadasboton;
	
	/** The comer. 
	 * este boton añade una carta al jugador al ser usado
	 * */
	private Carta comer;
	/** The imagen. 
	 * imagen actual que será enviada al sistema
	 * */
	private ImageIcon imagen;
	
	/** The gano J 2.
	 * si esto es true, significa que gano el computador
	 */
	private boolean ganoJ2 = false;
	
	/** The gano J 1. 
	 * si esto es true significa que gano el jugador
	 * */
	private boolean ganoJ1 = false;

	/** The juego. 
	 *  el proceso actual del juego
	 */
	private ProcesoOchoLoco juego;
	
	/** The mazo J 1. 
	 * cartas en mano del jugador
	 */
	private JPanel mazoJ1;
	
	/** The mazo J 2. 
	 * cartas en mano del computador
	 */
	private JPanel mazoJ2;
	
	/** The baraja. 
	 * la baraja de la que se extraen cartas 
	 */
	private JPanel baraja;
	
	/** The usadas. 
	 * las cartas jugadar
	 */
	private JPanel usadas;
	
	/** The escucha. */
	private Escucha escucha = new Escucha();
	
	/**
	 * Instantiates a new GUI ocho loco.
	 */
	private Container contenedor = this.getContentPane();
	
	/**
	 * Instantiates a new GUI ocho loco.
	 */
	public GUIOchoLoco(){
		juego = new ProcesoOchoLoco();
		
		contenedor.setLayout(new BorderLayout());
		GUIJugar();
		this.setTitle("Ocho Loco");
		this.pack();
		this.setResizable(true);
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
	}
	
	/**
	 * GUI jugar.
	 * aqui se produce el desarrollo de la interfaz gráfica
	 */
	private void GUIJugar() {
		juego.iniciarJuego();
		crearMazo1();
		crearMazo2();
		crearbaraja();
		crearUsadas();
		
		continuarjuego();
	}
	
	/**
	 * Crear mazo 1.
	 */
	private void crearMazo1() {
		mazoJ1 = new JPanel();
		mazoJ1.setBackground(Color.DARK_GRAY);
		for(int i = 0; i< juego.getBarajaJ1().size()-1;i++) {
			Tarjeta = juego.getBarajaJ1().get(i);
			Tarjeta.setVisible(true);
			juego.getBarajaJ1().get(i).setCara("Grandes");
			Tarjeta.setIcon(Tarjeta.getCara());
			Tarjeta.addActionListener(escucha);
			mazoJ1.add(Tarjeta);
		}
		contenedor.add(mazoJ1,BorderLayout.NORTH);
	}
	
	/**
	 * Crear mazo 2.
	 */
	private void crearMazo2() {
		mazoJ2 = new JPanel();
		mazoJ2.setBackground(Color.BLUE);
		for(int i = 0; i< juego.getBarajaJ2().size()-1;i++) {
			Tarjeta = juego.getBarajaJ2().get(i);
			Tarjeta.setVisible(true);
			juego.getBarajaJ2().get(i).setCara("Medianas");
			imagen = new ImageIcon("src/Imagenes/Cartas Medianas/Caratula.png");
			Tarjeta.setIcon(imagen);
			mazoJ2.add(Tarjeta);
		}
		contenedor.add(mazoJ2,BorderLayout.SOUTH);
	}
	
	/**
	 * Crearbaraja.
	 */
	private void crearbaraja() {
		baraja = new JPanel();
		baraja.setBackground(Color.GRAY);
		comer = new Carta();
		imagen = new ImageIcon("src/Imagenes/Cartas Medianas/Caratula.png");
		comer.setIcon(imagen);
		comer.addActionListener(escucha);
		baraja.add(comer);
		contenedor.add(baraja,BorderLayout.WEST);
		
	}
	
	/**
	 * Crear usadas.
	 */
	private void crearUsadas() {
		usadas = new JPanel();
		usadas.setBackground(Color.GRAY);
		usadasboton = juego.getusadas().get(juego.getusadas().size()-1);
		imagen = new ImageIcon("src/Imagenes/Cartas Medianas/"+juego.getusadas().get(juego.getusadas().size()-1).getIdentificador()+juego.getusadas().get(juego.getusadas().size()-1).getTipo()+".png");
		usadasboton.setIcon(imagen);
		usadas.add(usadasboton);
		contenedor.add(usadas,BorderLayout.EAST);
	}
	/**
	 * Continuarjuego.
	 */
	public void continuarjuego() {
		if(ganoJ2 = false) {
			if(juego.getTurno() == false) {
				juego.jugadorAutomatico();
				contenedor.remove(mazoJ1);
				contenedor.remove(mazoJ2);
				contenedor.remove(usadas);
				contenedor.remove(baraja);
				crearMazo1();
				crearMazo2();
				crearbaraja();
				crearUsadas();
				revalidate();
				juego.setTurno();
				}
			}else if(ganoJ1) {
				JOptionPane.showConfirmDialog(null, "gana el jugador 1");
				System.runFinalization();
				System.exit(1);
			}else if(ganoJ2) {
				JOptionPane.showConfirmDialog(null, "gana el jugador 2");
				System.runFinalization();
				System.exit(1);
				}
		}

	/**
	 * The Class Escucha.
	 */
	private class Escucha implements ActionListener{

		/**
		 * Action performed.
		 *
		 * @param arg0 the arg 0
		 */
		@Override
		public void actionPerformed(ActionEvent arg0) {
			Carta auxiliar = (Carta) arg0.getSource();
			int numPosicion = juego.getBarajaJ1().indexOf(auxiliar);
			System.out.println();
			System.out.println("auxiliar es"+auxiliar.getTipo()+auxiliar.getIdentificador());
			boolean debeComer = false;
			int contador = 0;
			if(arg0.getSource() != comer && juego.getBarajaJ1().contains(auxiliar)) {
				juego.dejarCarta(juego.getBarajaJ1(), numPosicion);
				contenedor.remove(mazoJ1);
				crearMazo1();
				contenedor.remove(mazoJ2);
				crearMazo2();
				contenedor.remove(usadas);
				crearUsadas();
				contenedor.remove(baraja);
				crearbaraja();
				revalidate();
				juego.setTurno();
			} else if(arg0.getSource() == comer) {
				for(int i = 0; i< juego.getBarajaJ1().size();i++) {
					if(juego.evaluarCartas(juego.getBarajaJ1().get(i))) {
						contador++;
					}
					if(contador >0) {
						debeComer = false;
					}else if(contador == 0) {
						debeComer = true;
					}
				}
				if(debeComer) {
					contador = 0;
					debeComer = false;
					juego.tomarCarta(juego.getBarajaJ1());
					contenedor.remove(mazoJ1);
					crearMazo1();
					contenedor.remove(mazoJ2);
					crearMazo2();
					contenedor.remove(usadas);
					crearUsadas();
					contenedor.remove(baraja);
					crearbaraja();
					revalidate();
					juego.setTurno();						
				}
			}
		}
	}
}
