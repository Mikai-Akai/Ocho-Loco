/*
 * 
 */
package archivos;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

// TODO: Auto-generated Javadoc
/**
 * The Class ProcesoOchoLoco.
 */
public class ProcesoOchoLoco {
	
	/** The baraja. */
	private ArrayList<Carta> baraja = new ArrayList<Carta>(0);
	
	/** The en mano jugador 1. */
	private ArrayList<Carta> enManoJugador1 = new ArrayList<Carta>(0);
	
	/** The en mano jugador 2. */
	private ArrayList<Carta> enManoJugador2 = new ArrayList<Carta>(0);
	
	/** The en juego. */
	private ArrayList<Carta> enJuego = new ArrayList<Carta>(0);
	
	/** The aleatorio. */
	private Random aleatorio = new Random();
	
	private boolean turno = true;
	/**
	 * Crear baraja.
	 *
	 * @param e the e
	 */
	public void crearBaraja(ArrayList<Carta> e) {
		for(int i = 1; i<53;i++) {
			//se crea la plantilla a usar para generar carta y se le asigna un tipo y numero
			Carta carta = new Carta();
			if(i <= 13 && i > -1) {
				carta.setTipo("Corazones");
				carta.setIdentificador(i);	
			}else if(i <= 26 && i > 13) {
				carta.setTipo("Diamantes");
				carta.setIdentificador(i-13);
			}else if(i <= 39 && i > 26) {
				carta.setTipo("Treboles");
				carta.setIdentificador(i-26);
			}else if(i <= 52 && i > 39) {
				carta.setTipo("Picas");
				carta.setIdentificador(i-39);
			}else {
				//si por algun motivo no se puede asignar un numero y tipo a la carta, se limpia la baraja y se reinicia la funcion.
				e.clear();
				crearBaraja(e);
			}
			//en el momento que la carta esta lista se añade a la baraja
			e.add(carta);
		}
	}
	
	/**
	 * Revolver baraja.
	 *
	 * @param r the r
	 */
	public void revolverBaraja(ArrayList<Carta> r) {
		//mediante la funcion shuffle mezclamos la posicion de las cartas con un indice aleatorio, cada vez que se revuelven quedan en distinta posicion
		Collections.shuffle(r, aleatorio);
	}
	
	/**
	 * Sacar primer carta.
	 */
	public void sacarPrimerCarta() {
		enJuego.add(baraja.remove(0));
	}
	
	/**
	 * Iniciar juego.
	 */
	public void iniciarJuego() {
		//funcion que da inicio a la fase 1 del juego, la creacion de la baraja, el posicionamiento de la primera carta y la entrega de cartas a los jugadores
		crearBaraja(baraja);
		revolverBaraja(baraja);
		sacarPrimerCarta();
		repartirCartas();
	}
	
	/**
	 * Repartir cartas.
	 */
	public void repartirCartas() {
		for(int a = 0; a <9;a++) {
			enManoJugador1.add(baraja.remove(0));
			}
		for(int b = 0; b <9;b++) {
			enManoJugador2.add(baraja.remove(0));
		}
	}
	/**
	 * Reunir mazos.
	 */
	public void limpiarMazos() {
		//resta funcion elimina las cartas en todos los mazos para un nuevo juego
		baraja.clear();
		enJuego.clear();
		enManoJugador1.clear();
		enManoJugador2.clear();
	}
	
	/**
	 * Jugador automatico.
	 */
	public void jugadorAutomatico() {
		int contador = 0;
		//este será el jugador "computador", primero usa la funcion evaluar cartas
		for(int i = 0; i < enManoJugador2.size();i++) {
			if(evaluarCartas(enManoJugador2.get(i))) {
				dejarCarta(enManoJugador2.get(i));
				break;
			}else {
				contador++;
				if(contador == enManoJugador2.size()) {
					tomarCarta(enManoJugador2);
				}
			}
		}
	}
	
	/**
	 * Evaluar cartas.
	 *
	 * @param enMano the en mano
	 * @return true
	 */
	public boolean evaluarCartas(Carta enMano) {
		//la carta a evaluar en mano del jugador depende de la posicion que se asigne a evaluar
		Carta base = enJuego.get(enJuego.size()-1);
		//la carta base tiene la posicion final de la baraja en juego y la compara 
		if(enMano.getIdentificador() == base.getIdentificador() || enMano.getTipo() == base.getTipo()) {
			return true;
		}else {
			return false;
			// si no se cumple ninguna de las anteriores, es que la carta no coincide
			}
		}
	
	/**
	 * Tomar carta.
	 *
	 * @param Jugador the jugador
	 */
	public void tomarCarta(ArrayList<Carta> Jugador) {
		Carta As = new Carta();
		As.setIdentificador(1);
		Carta Carta2 = new Carta();
		Carta2.setIdentificador(2);
		Carta Carta3 = new Carta();
		Carta3.setIdentificador(3);
		Carta Carta8 = new Carta();
		Carta8.setIdentificador(8);
		//Jugador.add(baraja.remove(baraja.size()-1));
		if(enJuego.get(enJuego.size()-1).getIdentificador() == As.getIdentificador()) {
			for(int i = 0; i< 3;i++) {
				Jugador.add(baraja.remove(baraja.size()-1));
				}
			}else if(enJuego.get(enJuego.size()-1).getIdentificador() == Carta2.getIdentificador()) {
				for(int i = 0; i< 2;i++) {
					Jugador.add(baraja.remove(baraja.size()-1));
				}
			}else if(enJuego.get(enJuego.size()-1).getIdentificador() == Carta3.getIdentificador()) {
				turno = !turno;
			}else if(enJuego.get(enJuego.size()-1).getIdentificador() == Carta8.getIdentificador()) {
				
			}else {
				Jugador.add(baraja.remove(baraja.size()-1));
			}
		}
	
	/**
	 * Dejar carta.
	 *
	 * @param Jugador the jugador
	 */
	public void dejarCarta(Carta Jugador) {
		if(evaluarCartas(Jugador)) {
			enJuego.add(Jugador);};
	}
	
	public boolean getTurno() {
		return turno;
	}
	public void setTurno() {
		turno = !turno;
	}
	/**
	 * Gets the baraja J 1.
	 *
	 * @return the baraja J 1
	 */
	public ArrayList<Carta> getBarajaJ1() {
		return enManoJugador1;
	}
	
	/**
	 * Gets the baraja J 2.
	 *
	 * @return the baraja J 2
	 */
	public ArrayList<Carta> getBarajaJ2() {
		return enManoJugador2;
	}
	
	/**
	 * Gets the usadas.
	 *
	 * @return the usadas
	 */
	public ArrayList<Carta >getusadas() {
		return enJuego;
	}
}