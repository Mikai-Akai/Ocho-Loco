/*
 * 
 */
package archivos;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

// TODO: Auto-generated Javadoc
/**
 * The Class ProcesoOchoLoco.
 */
public class ProcesoOchoLoco {
	
	/** The baraja. */
	private ArrayList<Carta> baraja = new ArrayList<Carta>(0);
	
	/** The en mano jugador 1. */
	private ArrayList<Carta> enManoJugador1 = new ArrayList<Carta>(0);
	
	/** The en mano jugador 2. */
	private ArrayList<Carta> enManoJugador2 = new ArrayList<Carta>(0);
	
	/** The en juego. */
	private ArrayList<Carta> enJuego = new ArrayList<Carta>(0);
	
	/** The aleatorio. */
	private Random aleatorio = new Random();
	
	/**
	 * Crear baraja.
	 *
	 * @param e the e
	 */
	public void crearBaraja(ArrayList<Carta> e) {
		for(int i = 1; i<53;i++) {
			//se crea la plantilla a usar para generar carta y se le asigna un tipo y numero
			Carta carta = new Carta();
			if(i <= 13 && i > -1) {
				carta.setTipo("Corazones");
				carta.setIdentificador(i);	
			}else if(i <= 26 && i > 13) {
				carta.setTipo("Diamantes");
				carta.setIdentificador(i-13);
			}else if(i <= 39 && i > 26) {
				carta.setTipo("Treboles");
				carta.setIdentificador(i-26);
			}else if(i <= 52 && i > 39) {
				carta.setTipo("Picas");
				carta.setIdentificador(i-39);
			}else {
				//si por algun motivo no se puede asignar un numero y tipo a la carta, se limpia la baraja y se reinicia la funcion.
				e.clear();
				crearBaraja(e);
			}
			//en el momento que la carta esta lista se añade a la baraja
			e.add(carta);
		}
	}
	
	/**
	 * Revolver baraja.
	 *
	 * @param r the r
	 */
	public void revolverBaraja(ArrayList<Carta> r) {
		//mediante la funcion shuffle mezclamos la posicion de las cartas con un indice aleatorio, cada vez que se revuelven quedan en distinta posicion
		Collections.shuffle(r, aleatorio);
	}
	
	/**
	 * Sacar primer carta.
	 */
	public void sacarPrimerCarta() {
		enJuego.add(baraja.remove(0));
	}
	
	/**
	 * Iniciar juego.
	 */
	public void iniciarJuego() {
		//funcion que da inicio a la fase 1 del juego, la creacion de la baraja, el posicionamiento de la primera carta y la entrega de cartas a los jugadores
		crearBaraja(baraja);
		revolverBaraja(baraja);
		sacarPrimerCarta();
		repartirCartas();
	}
	
	/**
	 * Repartir cartas.
	 */
	public void repartirCartas() {
		for(int a = 0; a <8;a++) {
			enManoJugador1.add(baraja.remove(0));
			}
		for(int b = 0; b <8;b++) {
			enManoJugador2.add(baraja.remove(0));
		}
	}
	/**
	 * Reunir mazos.
	 */
	public void limpiarMazos() {
		//resta funcion elimina las cartas en todos los mazos para un nuevo juego
		baraja.clear();
		enJuego.clear();
		enManoJugador1.clear();
		enManoJugador2.clear();
	}
	
	/**
	 * Jugador automatico.
	 */
	public void jugadorAutomatico() {
		int contador = 0;
		//este será el jugador "computador", primero usa la funcion evaluar cartas
		for(int i = 0; i < enManoJugador2.size();i++) {
			if(evaluarCartas(enManoJugador2,i)) {
				//si la respuesta es true, el jugador deja la carta en el mazo de juego y finaliza esta funcion
				enJuego.add(enManoJugador2.remove(i));
				break;
			}else {
				// se acumula un contaddor cada vez que la carta no coincida
				contador++;
				}
			if(contador == enManoJugador2.size()) {
				//si no tiene cartas que coincidan el jugador saca una de la baraja y la añade a su mazo
				enManoJugador2.add(baraja.remove(0));
				contador = 0;
			}
		}
	}
	
	/**
	 * Evaluar cartas.
	 *
	 * @param enMano the en mano
	 * @param pos1 the pos 1
	 * @param enJuego the en juego
	 * @param pos2 the pos 2
	 * @return true, if successful
	 */
	public boolean evaluarCartas(ArrayList <Carta> enMano, int pos1) {
		//esta funcion recibe la baraja del jugador, la baaraja en el juego y las posiciones a evaluar
		Carta evaluada = enMano.get(pos1);
		//la carta a evaluar en mano del jugador depende de la posicion que se asigne a evaluar
		Carta base = enJuego.get(enJuego.size()-1);
		//la carta base tiene la posicion final de la baraja en juego y la compara 
		if(evaluada.getIdentificador() == base.getIdentificador() || evaluada.getTipo() == base.getTipo()) {
			return true;
		}else {
			return false;
			// si no se cumple ninguna de las anteriores, es que la carta no coincide
			}
		}
	
	public void tomarCarta(ArrayList<Carta> Jugador) {
		Jugador.add(baraja.remove(baraja.size()-1));
	}
	public void dejarCarta(ArrayList<Carta> Jugador, int posicion) {
		if(evaluarCartas(Jugador,posicion))enJuego.add(Jugador.remove(posicion));
	}
	/**
	 * Gets the baraja J 1.
	 *
	 * @return the baraja J 1
	 */
	public ArrayList<Carta> getBarajaJ1() {
		return enManoJugador1;
	}
	
	/**
	 * Gets the baraja J 2.
	 *
	 * @return the baraja J 2
	 */
	public ArrayList<Carta> getBarajaJ2() {
		return enManoJugador2;
	}
	
	/**
	 * Gets the usadas.
	 *
	 * @return the usadas
	 */
	public ArrayList<Carta >getusadas() {
		return enJuego;
	}
}