/*
 * 
 */
package archivos;

import javax.swing.ImageIcon;
import javax.swing.JButton;

// TODO: Auto-generated Javadoc
/**
 * The Class Carta.
 */
@SuppressWarnings("serial")
public class Carta extends JButton{
	
	private int posicion = 0;
	/** The cara. */
	private ImageIcon cara;
	
	/** The identificador. */
	private int identificador;
	
	/** The tipo. */
	private String tipo;
	
	/** The revelado. */
	private boolean revelado;

	/**
	 * Gets the cara.
	 * @return 
	 *
	 * @return the cara
	 */
	public ImageIcon getCara() {
		return cara;
	}

	/**
	 * Sets the cara.
	 *
	 * @param tamano the new cara
	 */
	public void setCara(String tamano) {
		cara = new ImageIcon("src/Imagenes/Cartas "+tamano+"/"+identificador+tipo+".png");
	}

	/**
	 * Gets the identificador.
	 *
	 * @return the identificador
	 */
	public int getIdentificador() {
		return identificador;
	}

	/**
	 * Sets the identificador.
	 *
	 * @param identificador the new identificador
	 */
	public void setIdentificador(int identificador) {
		this.identificador = identificador;
	}

	/**
	 * Gets the tipo.
	 *
	 * @return the tipo
	 */
	public String getTipo() {
		return tipo;
	}

	/**
	 * Sets the tipo.
	 *
	 * @param tipo the new tipo
	 */
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	/**
	 * Checks if is revelado.
	 *
	 * @return true, if is revelado
	 */
	public boolean isRevelado() {
		return revelado;
	}

	/**
	 * Sets the revelado.
	 */
	public void setRevelado() {
		this.revelado = !revelado;
	}
}
