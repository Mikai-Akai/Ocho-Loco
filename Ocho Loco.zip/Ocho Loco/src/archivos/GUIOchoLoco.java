/*
 * 
 */
package archivos;

import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;

// TODO: Auto-generated Javadoc
/**
 * The Class GUIOchoLoco.
 */
@SuppressWarnings("serial")
public class GUIOchoLoco extends JFrame {
	
	/** The Tarjeta. */
	@SuppressWarnings("unused")
	private JButton Tarjeta;
	
	/** The imagen. */
	@SuppressWarnings("unused")
	private ImageIcon imagen;
	
	/** The columnas. */
	@SuppressWarnings("unused")
	private int filas, columnas;
	
	/** The juego. */
	private ProcesoOchoLoco juego;
	
	/** The escucha. */
	@SuppressWarnings("unused")
	private Escucha escucha;
	
	/**
	 * Instantiates a new GUI ocho loco.
	 */
	public GUIOchoLoco(){
		escucha = new Escucha();
		juego = new ProcesoOchoLoco();
		GUIJugar();
		this.setTitle("Ocho Loco");
		this.setSize(600, 400);
		this.setResizable(true);
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
	}
	
	/**
	 * GUI jugar.
	 */
	private void GUIJugar() {
		// TODO Auto-generated method stub
		Container contenedor = this.getContentPane();
		contenedor.setLayout(new FlowLayout());
		juego.iniciarJuego();
	}

	/**
	 * The Class Escucha.
	 */
	private class Escucha implements ActionListener{

		/**
		 * Action performed.
		 *
		 * @param evento the evento
		 */
		@Override
		public void actionPerformed(ActionEvent evento) {
			// TODO Auto-generated method stub
			
		}
		
	}
}
