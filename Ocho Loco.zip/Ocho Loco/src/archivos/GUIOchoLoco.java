/*
 * 
 */
package archivos;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

// TODO: Auto-generated Javadoc
/**
 * The Class GUIOchoLoco.
 */
@SuppressWarnings("serial")
public class GUIOchoLoco extends JFrame {
	
	/** The Tarjeta. */
	private Carta Tarjeta;
	
	/** The usadasboton. */
	private JButton comer,usadasboton;
	/** The imagen. */
	private ImageIcon imagen;
	
	/** The gano J 2. */
	private boolean turno = true,ganoJ1 = false,ganoJ2 = false;
	
	/** The juego. */
	private ProcesoOchoLoco juego;
	
	/** The usadas. */
	private JPanel mazoJ1,mazoJ2,baraja,usadas;
	
	/** The escucha. */
	private Escucha escucha;
	
	/**
	 * Instantiates a new GUI ocho loco.
	 */
	public GUIOchoLoco(){
		escucha = new Escucha();
		juego = new ProcesoOchoLoco();
		GUIJugar();
		this.setTitle("Ocho Loco");
		//this.setPreferredSize(size);
		this.pack();
		this.setResizable(true);
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
	}
	
	/**
	 * GUI jugar.
	 */
	private void GUIJugar() {
		// TODO Auto-generated method stub
		Container contenedor = this.getContentPane();
		contenedor.setLayout(new BorderLayout());
		juego.iniciarJuego();
		mazoJ1 = new JPanel();
		mazoJ1.setBackground(Color.DARK_GRAY);
		for(int i = 0; i< juego.getBarajaJ1().size()-1;i++) {
			Tarjeta = juego.getBarajaJ1().get(i);
			Tarjeta.setVisible(true);
			juego.getBarajaJ1().get(i).setCara("Grandes");
			Tarjeta.setIcon(Tarjeta.getCara());
			Tarjeta.addMouseListener(escucha);
			mazoJ1.add(Tarjeta);
		}
		contenedor.add(mazoJ1,BorderLayout.NORTH);
		
		mazoJ2 = new JPanel();
		mazoJ2.setBackground(Color.BLUE);
		for(int i = 0; i< juego.getBarajaJ2().size()-1;i++) {
			Tarjeta = juego.getBarajaJ2().get(i);
			Tarjeta.setVisible(true);
			juego.getBarajaJ2().get(i).setCara("Medianas");
			imagen = new ImageIcon("src/Imagenes/Cartas Medianas/Caratula.png");
			Tarjeta.setIcon(imagen);
			mazoJ2.add(Tarjeta);
		}
		contenedor.add(mazoJ2,BorderLayout.SOUTH);
		
		baraja = new JPanel();
		baraja.setBackground(Color.GRAY);
		comer = new JButton();
		imagen = new ImageIcon("src/Imagenes/Cartas Medianas/Caratula.png");
		comer.setIcon(imagen);
		baraja.add(comer);
		contenedor.add(baraja,BorderLayout.WEST);
		
		usadas = new JPanel();
		usadas.setBackground(Color.DARK_GRAY);
		usadasboton = new JButton();
		imagen = new ImageIcon("src/Imagenes/Cartas Medianas/"+juego.getusadas().get(juego.getusadas().size()-1).getIdentificador()+juego.getusadas().get(juego.getusadas().size()-1).getTipo()+".png");
		usadasboton.setIcon(imagen);
		usadas.add(usadasboton);
		contenedor.add(usadas,BorderLayout.EAST);
		continuarjuego();
	}
	
	/**
	 * Continuarjuego.
	 */
	@SuppressWarnings("unused")
	public void continuarjuego() {
		while(ganoJ2 = false && ganoJ1 == false) {
			if(turno) {
				if(juego.getBarajaJ1().size() == 0) {
					ganoJ1 = true;
				}else if(turno) {
					if(juego.getBarajaJ1().size() == 0) {
				}
					ganoJ1 = true;
					}
				}
			}
		if(ganoJ1) {
			JOptionPane.showConfirmDialog(null, "gana el jugador 1");
		}else if(ganoJ2) {
			JOptionPane.showConfirmDialog(null, "gana el jugador 2");
		}else {
		}
	}

	/**
	 * The Class Escucha.
	 */
	private class Escucha implements MouseListener{

		/**
		 * Mouse clicked.
		 *
		 * @param arg0 the arg 0
		 */
		@Override
		public void mouseClicked(MouseEvent arg0) {
			// TODO Auto-generated method stub
			turno = !turno;
		}

		/**
		 * Mouse entered.
		 *
		 * @param arg0 the arg 0
		 */
		@Override
		public void mouseEntered(MouseEvent arg0) {
			// TODO Auto-generated method stub
			
		}

		/**
		 * Mouse exited.
		 *
		 * @param arg0 the arg 0
		 */
		@Override
		public void mouseExited(MouseEvent arg0) {
			// TODO Auto-generated method stub
			
		}

		/**
		 * Mouse pressed.
		 *
		 * @param arg0 the arg 0
		 */
		@Override
		public void mousePressed(MouseEvent arg0) {
			// TODO Auto-generated method stub
			
		}

		/**
		 * Mouse released.
		 *
		 * @param arg0 the arg 0
		 */
		@Override
		public void mouseReleased(MouseEvent arg0) {
			// TODO Auto-generated method stub
			
		}
		
	}
}
