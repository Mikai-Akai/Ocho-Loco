package archivos;

import java.awt.Container;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class ProcesoOchoLoco {
	private List<Carta> baraja = new ArrayList<>(52);
	
	public void crearBaraja() {
		for(int i = 1; i<53;i++) {
			Carta carta = new Carta();
			if(i <= 13) {
				carta.setTipo("Corazones");
				carta.setIdentificador(i);
			}else if(i <= 26) {
				carta.setTipo("Diamantes");
				carta.setIdentificador(i-13);
			}else if(i <= 39) {
				carta.setTipo("Treboles");
				carta.setIdentificador(i-26);
			}else if(i <= 52) {
				carta.setTipo("Picas");
				carta.setIdentificador(i-39);
			}
			baraja.set(i, carta);
		}
	}
	
	public void SacarCarta() {
		Random random = new Random();
		Carta[] mazoRevuelto = new Carta[52];
		int contador = 0;
		while(baraja.size() > 1) {
			int randomIndice = random.nextInt(baraja.size());
			mazoRevuelto[contador] = baraja.get(randomIndice);
			baraja.remove(randomIndice);
		}
		
	}
}
