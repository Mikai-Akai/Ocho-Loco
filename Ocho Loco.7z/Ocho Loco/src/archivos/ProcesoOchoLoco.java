package archivos;

import java.awt.Container;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import javax.swing.JOptionPane;

public class ProcesoOchoLoco {
	private Carta[] baraja = new Carta[52];
	private Carta[] enMano = new Carta[10];
	private Carta[] enJuego = new Carta[52];
	public void crearBaraja() {
		for(int i = 1; i<53;i++) {
			Carta carta = new Carta();
			if(i <= 13 && i > -1) {
				carta.setTipo("Corazones");
				carta.setIdentificador(i);
			}else if(i <= 26 && i > 13) {
				carta.setTipo("Diamantes");
				carta.setIdentificador(i-13);
			}else if(i <= 39 && i > 26) {
				carta.setTipo("Treboles");
				carta.setIdentificador(i-26);
			}else if(i <= 52 && i > 39) {
				carta.setTipo("Picas");
				carta.setIdentificador(i-39);
			}else {
				baraja = new Carta[0];
				crearBaraja();
			}
			baraja[i-1] = carta;
			Carta[] temporal = new Carta[baraja.length+1];
		}
	}
	
	public void RevolverBaraja() {
		Random random = new Random();
		Carta[] mazoRevuelto = new Carta[52];
		int contador = 0;
		while(baraja.length > 1) {
			int randomIndice = random.nextInt(baraja.length);
			mazoRevuelto[contador] = baraja[randomIndice];
			baraja[randomIndice] = null;
			int q = 0, w = 0;
			Carta[] respaldo = new Carta[baraja.length-1];
			while(q < respaldo.length) {
				if(baraja[q] == null) {
					w--;
				}else {
					respaldo[q] = baraja[w];
				}
				q++;
				w++;
			}
			baraja = respaldo;
			respaldo = new Carta[0];
		}
		int j = 0;
		while(j < 52) {
			baraja[j] = mazoRevuelto[j];
			j++;
		};
	}
	public void SacarPrimerCarta() {
		Carta[] respaldo;
		respaldo = enMano;
		enMano = new Carta[respaldo.length+1];
		enMano = respaldo;
		enMano[enMano.length-1] = baraja[0];
		baraja[0] = null;
	}
}
