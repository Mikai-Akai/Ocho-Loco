package archivos;

import javax.swing.ImageIcon;
import javax.swing.JButton;

public class Carta extends JButton{
	
	private ImageIcon cara;
	
	private int identificador;
	
	private String tipo;
	
	private boolean revelado;

	public ImageIcon getCara() {
		return cara;
	}

	public void setCara(String tama�o) {
		cara = new ImageIcon("/Imagenes/Cartas"+tama�o+"/"+identificador+tipo+".png");
	}

	public int getIdentificador() {
		return identificador;
	}

	public void setIdentificador(int identificador) {
		this.identificador = identificador;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public boolean isRevelado() {
		return revelado;
	}

	public void setRevelado() {
		this.revelado = !revelado;
	}
}
