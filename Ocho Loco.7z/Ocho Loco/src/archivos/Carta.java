package archivos;

import javax.swing.ImageIcon;
import javax.swing.JButton;

public class Carta extends JButton{
	
	private ImageIcon cara;
	
	private int identificador;
	
	private String tipo;
	
	private boolean revelado;

	private ImageIcon getCara() {
		return cara;
	}

	private void setCara(ImageIcon cara) {
		this.cara = cara;
	}

	private int getIdentificador() {
		return identificador;
	}

	private void setIdentificador(int identificador) {
		this.identificador = identificador;
	}

	private String getTipo() {
		return tipo;
	}

	private void setTipo(String tipo) {
		this.tipo = tipo;
	}

	private boolean isRevelado() {
		return revelado;
	}

	private void setRevelado() {
		this.revelado = !revelado;
	}
}
