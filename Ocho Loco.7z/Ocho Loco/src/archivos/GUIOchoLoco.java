package archivos;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;

public class GUIOchoLoco extends JFrame {
	private JButton Tarjeta;
	private ImageIcon imagen;
	private int filas, columnas;
	ProcesoOchoLoco juego;
	private Escucha escucha;
	public GUIOchoLoco(){
		escucha = new Escucha();
		juego = new ProcesoOchoLoco();
		GUIJugar();
		this.setTitle("Ocho Loco");
		this.setSize(600, 400);
		this.setResizable(true);
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
	}
	
	private void GUIJugar() {
		// TODO Auto-generated method stub
		
	}

	private class Escucha implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent evento) {
			// TODO Auto-generated method stub
			
		}
		
	}
}
